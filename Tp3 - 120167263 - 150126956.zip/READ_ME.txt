/*
Universidade de Brasilia - 01/2018
CIC 117889 - Técnicas de Programação
Professor Fernando Albuquerque
Trabalho Pratico 3

Alunos: 	Bruno Takashi Tengan                12/0167263
			Gabriel Arimatéa					15/0126956
*/

*** DETALHES DA COMPILAÇÃO ***
O código foi testado e compilado utilizando o computador com os seguintes sistemas e comando de compilação:

*SO: Ubuntu 5.4.0-6ubuntu1~16.04.9
*Compilador: gcc 5.4.0 20160609
*comando: g++ -Wall -Wextra -g Main.cpp
