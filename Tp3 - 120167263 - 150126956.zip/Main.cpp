/*
Universidade de Brasilia - 01/2018
CIC 117889 - Técnicas de Programação
Professor Fernando Albuquerque
Trabalho Pratico 3

Alunos: 	Bruno Takashi Tengan                12/0167263
			Gabriel Arimatéa					15/0126956
*/

#include "Navegacao.cpp"

int main(){
	cout << endl << "\tBem Vindo." << endl;

	// Executa tela inicial.
	NavFrontPage nFrontPage;
	nFrontPage.execute();

	return 0;
}